﻿window.getWidth = () => window.innerWidth;
window.getHeight = () => window.innerHeight;